/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calculator;

/**
 *
 * @author Lenovo
 */
public class Calculator {
    //data members
    private double num1;
    private double num2;
    private double result;
    //constructors
    public Calculator(){
    num1 = 0.0;
    num2 = 0.0;
    }
    //setters
    public void setNum1(double num1){
        this.num1 = num1;
    }
    public void setNum2(double num2) {
        this.num2 = num2;
    }
    
    
    //getters
    public double getResult() {
        return result;
    }
    
    //methods
    
    public void add(){
        result = num1 + num2;
    }
    public void substract(){
        result = num1 - num2;
    }
    public void multiply(){
        result = num1 * num2;
    }
    public void divide(){
        result = num1 / num2;
    }

    

    


    
       
    
    
}
