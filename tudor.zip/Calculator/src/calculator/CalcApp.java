/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calculator;

import java.util.Scanner;

/**
 *
 * @author Lenovo
 */
public class CalcApp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        double num1;
        double num2;
        double result;
        
        //declare Scanner
        
        Scanner scan = new Scanner(System.in);
        Calculator myCalc = new Calculator();
        System.out.println("Enter num1: ");
        num1 = scan.nextDouble();
        myCalc.setNum1(num1);
        
        System.out.println("Enter num2: ");
        num2 = scan.nextDouble();
        myCalc.setNum2(num2);
        
        myCalc.add();
        result = myCalc.getResult();
        System.out.println("Result: " + result);
        
        
    }
    
}
