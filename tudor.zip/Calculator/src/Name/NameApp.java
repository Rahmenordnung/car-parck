/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Name;

import java.util.Scanner;

/**
 *
 * @author Lenovo
 */
public class NameApp {
    public static void main(String args[]){
    //declare variables
    String name;
    int len;
    char firstLetter, lastLetter;
    
    //declare & create objects
    Name myName = new Name();
    
    //input 
    Scanner scan = new Scanner(System.in);
    name = scan.next();
    
    //process
    myName.compute();
    
    //output
    len = myName.getLen();
    firstLetter = myName.getFirstLetter();
    lastLetter = myName.getLastLetter();
        System.out.println("Your name has " + len + "Thefirst letter is" + firstLetter + "The last Letter is" + lastLetter);
    
    
    
    
    }
    
    
    
    
    
    
    
}
