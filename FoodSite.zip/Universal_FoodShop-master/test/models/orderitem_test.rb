require 'test_helper'

class OrderitemTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
