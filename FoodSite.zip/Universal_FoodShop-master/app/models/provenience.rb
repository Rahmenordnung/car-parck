class Provenience < ApplicationRecord
end
