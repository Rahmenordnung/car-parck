
package carpark;

public class Appt implements Comparable<Appt> {
    String reg;
    String time;
    
    public Appt(String aReg, String aTime) {
        this.reg = aReg;
        this.time = aTime;
    }
    
    public String getReg() {
        return this.reg;
    }
    
    public String getTime() {
        return this.time;
    }
    
    public void setReg(String newReg) {
        this.reg = newReg;
    }
    
    public void setTime(String newTime) {
        this.time = newTime;
    }
    
    public int compareTo(Appt apt1) {
        return this.getReg().compareTo(apt1.getReg());
    }
}
