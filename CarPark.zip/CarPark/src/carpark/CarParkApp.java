
package carpark;

public class CarParkApp {

    public static void main(String[] args) {
        ApptTracker apt1 = new ApptTracker();
        new ApptTracker().setVisible(true);
    }
    
}
