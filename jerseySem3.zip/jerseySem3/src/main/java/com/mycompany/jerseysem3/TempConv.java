/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.jerseysem3;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

/**
 *
 * @author User
 */

@Path("/convertTemp")
public class TempConv {
//curl -vi -X "Accept: text/plain" GET -G "http://localhost:49000/api/convertTemp/CtoF/37"
@GET
@Produces(MediaType.TEXT_PLAIN)
@Path("CtoF/{param}")
    public Response CToF(@PathParam("param") double cent) { 
        double fah = (cent * 9/5) + 32;
        String output = cent + " C converted to deg F = " + fah + " F!";
        return Response.status(200).entity(output).build();
    }

//curl -vi -X "Accept: text/plain" GET -G "http://localhost:49000/api/convertTemp/FtoC/98.6"
@GET
@Produces(MediaType.TEXT_PLAIN)
@Path("FtoC/{param}")
    public Response FToC(@PathParam("param") double fah) { 
        double cent = (fah -32) * 5/9;
        String output = fah + " F converted to deg F = " + cent + " C!";
        return Response.status(200).entity(output).build();
    }

//curl -vi -X "Accept: text/xml" GET -G "http://localhost:49000/api/convertTemp/CToF_xml/37"
    
@GET
@Produces(MediaType.TEXT_XML)
@Path("CToF_xml/{param}")
    public String CToF_xml(@PathParam("param") double cent) { 
        double fah = (cent * 9/5) + 32;
        String output = cent + " C converted to deg F = " + fah + " F!";
        return "<?xml version=\"1.0\"?>" + "<temp_xml>" + cent + " C converted to deg F = " + fah + "</temp_xml>";
        //return Response.status(200).entity(output).build();
    }

//curl -vi -X "Accept: text/xml" GET -G "http://localhost:49000/api/convertTemp/FToC_xml/98.6"
@GET
@Produces(MediaType.TEXT_XML)
@Path("FToC_xml/{param}")
    public String FToC_xml(@PathParam("param") double fah) { 
        double cent = (fah -32) * 5/9;
        String output = fah + " F converted to deg F = " + cent + " C!";
        return "<?xml version=\"1.0\"?>" + "<temp_xml>" + fah + " C converted to deg F = " + cent + "</temp_xml>";
        //return Response.status(200).entity(output).build();
        
    }

//curl -vi -X "Accept: text/html" GET -G "http://localhost:49000/api/convertTemp/CToF_html/37"
    
@GET
@Produces(MediaType.TEXT_HTML)
@Path("CToF_html/{param}")
    public String CToF_html(@PathParam("param") double cent) { 
        double fah = (cent * 9/5) + 32;
        String output = cent + " C converted to deg F = " + fah + " F!";
        return "<html>" + "<title>" + "Celsius to Fahrenheit" + "</title>" + "<body><h1>" + cent + "<p> C converted to deg F = </p>" + fah + "</body></h1>" + "</html>";
        //return Response.status(200).entity(output).build();
    }

//curl -vi -X "Accept: text/html" GET -G "http://localhost:49000/api/convertTemp/FToC_html/98.6"
    
@GET
@Produces(MediaType.TEXT_HTML)
@Path("FToC_html/{param}")
    public String FToC_html(@PathParam("param") double fah) { 
        double cent = (fah -32) * 5/9;
        String output = fah + " F converted to deg F = " + cent + " C!";
        return "<html>" + "<title>" + "Celsius to Fahrenheit" + "</title>" + "<body><h1>" + fah + "<p> C converted to deg F = </p>" + cent + "</body></h1>" + "</html>";

        //return Response.status(200).entity(output).build();
        
    }        
}


